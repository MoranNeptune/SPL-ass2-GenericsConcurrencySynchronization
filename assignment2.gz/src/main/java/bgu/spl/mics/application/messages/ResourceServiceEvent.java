package bgu.spl.mics.application.messages;
import bgu.spl.mics.Event;


/**
 * An event that is sent when the logisticService wishes to deliver the book
 */
public class ResourceServiceEvent implements Event {

    private DeliveryEvent deliveryEvent; //holds the delivery event

    /**
     * ResourceServiceEvent constructor
     * @param deliveryEvent -holds the delivery event
     */
    public ResourceServiceEvent(DeliveryEvent deliveryEvent){
        this.deliveryEvent = deliveryEvent;
    }

    public DeliveryEvent getDeliveryMessage() {
        return deliveryEvent;
    }
}