package bgu.spl.mics.application.passiveObjects;

/**
 * A passiveObject that holds the name of the book that should be ordered in the startTick time
 */
public class OrderPair {

    String nameBook; //holds the name of the book
    Integer startTick; //holds the start tick time that the book should be ordered

    /**
     * OrderPair constructor
     * @param nameBook -holds the name of the book
     * @param startTick -holds the start tick time that the book should be ordered
     */
    public OrderPair(String nameBook, Integer startTick){
        this.nameBook=nameBook;
        this.startTick=startTick;
    }

    public int getStartTick() {
        return startTick;
    }

    public String getNameBook(){
        return nameBook;
    }
}
