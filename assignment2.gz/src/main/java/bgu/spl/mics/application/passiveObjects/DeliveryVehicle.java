package bgu.spl.mics.application.passiveObjects;

/**
 * Passive data-object representing a delivery vehicle of the store.
 * You must not alter any of the given public methods of this class.
 * <p>
 * You may add ONLY private fields and methods to this class.
 */
public class DeliveryVehicle {

	private int _license;		//license number of the vehicle
	private int _speed;			//the required amount of milliseconds are required for each delivery

	/**
	 * DeliveryVehicle constructor
	 * @param license -license number of the vehicle
	 * @param speed -the required amount of milliseconds are required for each delivery
	 */
	public DeliveryVehicle(int license, int speed) {
		this._license=license;
		this._speed=speed;
	}

	public int getLicense() {
		return _license;
	}

	public int getSpeed() {
		return _speed;
	}
	
	/**
     * Simulates a delivery by sleeping for the amount of time that 
     * it takes this vehicle to cover {@code distance} KMs.  
     * <p>
     * @param address -The address of the customer.
     * @param distance -The distance from the store to the customer.
     */
	public void deliver(String address, int distance) {
		try{
			//suspend execution of current thread for (distance*speed) period
			Thread.sleep(distance*_speed);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}
