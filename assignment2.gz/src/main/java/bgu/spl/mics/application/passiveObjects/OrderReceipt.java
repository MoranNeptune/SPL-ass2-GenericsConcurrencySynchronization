package bgu.spl.mics.application.passiveObjects;
import java.io.Serializable;

/**
 * Passive data-object representing a receipt that should 
 * be sent to a customer after the completion of a BookOrderEvent.
 * You must not alter any of the given public methods of this class.
 * <p>
 * You may add fields and methods to this class as you see fit (including public methods).
 */
public class OrderReceipt implements Serializable {

	private int _orderId;			//id if order
	private  String _seller;	    //name of the service that handled this order
	private int _customer;			//customer id
	private String _bookTitle;		//book name
	private int _price;				//the price of the book
	private int _issuedTick;		//the issued tick
	private int _orderTick;			//the order tick
	private int _processTick;		//the process tick

	/**
	 * OrderReceipt empty constructor
	 */
	public OrderReceipt(){}

	/**
	 * OrderReceipt constructor
	 * @param orderId -id if order
	 * @param seller -name of the service that handled this order
	 * @param customer -customer id
	 * @param bookTitle -book name
	 * @param price -the price of the book
	 * @param issuedTick -the issued tick
	 * @param orderTick -the order tick
	 * @param processTick -the process tick
	 */
	public OrderReceipt(int orderId, String seller, int customer, String bookTitle, int price, int issuedTick, int orderTick, int processTick) {
		this._orderId = orderId;
		this._seller = seller;
		this._customer = customer;
		this._bookTitle = bookTitle;
		this._price = price;
		this._issuedTick = issuedTick;
		this._orderTick = orderTick;
		this._processTick = processTick;
	}

	/**
	 * OrderReceipt copy constructor
	 * @param other -the receipt to be coped
	 */
	public OrderReceipt (OrderReceipt other){
		this._orderId = other.getOrderId();
		this._seller = other.getSeller();
		this._customer = other.getCustomerId();
		this._bookTitle = other.getBookTitle();
		this._price = other.getPrice();
		this._issuedTick = other.getIssuedTick();
		this._orderTick = other.getOrderTick();
		this._processTick = other.getProcessTick();
	}

	public int getOrderId() {
		return _orderId;
	}

	public String getSeller() {
		return _seller;
	}

	public int getCustomerId() {
		return _customer;
	}

	public String getBookTitle() {
		return _bookTitle;
	}

	public int getPrice() {
		return _price;
	}

	public int getIssuedTick() {
		return _issuedTick;
	}

	public int getOrderTick() {
		return _orderTick;
	}

	public int getProcessTick() {
		return _processTick;
	}

	public void setOrderId(int orderId){
		this._orderId=orderId;
	}

	public void setSeller(String seller){
		this._seller=seller;
	}

	public void setCustomerId(int customerId){
		this._customer=customerId;
	}

	public void setBookTitle(String bookTitle){
		this._bookTitle=bookTitle;
	}

	public void setPrice(int price){
		this._price=price;
	}

	public void setissuedTick(int issuedTick) {
		this._issuedTick=issuedTick;
	}

	public void setOrderTick(int orderTick){
		this._orderTick=orderTick;
	}

	public void setProccessTick(int proccessTick){
		this._processTick=proccessTick;
	}
}

