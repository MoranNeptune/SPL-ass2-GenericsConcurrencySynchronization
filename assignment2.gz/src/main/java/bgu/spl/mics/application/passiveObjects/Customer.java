package bgu.spl.mics.application.passiveObjects;

import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Passive data-object representing a customer of the store.
 * You must not alter any of the given public methods of this class.
 * <p>
 * You may add fields and methods to this class as you see fit (including public methods).
 */
public class Customer implements Serializable {

	private int _id;							//customer's id
	private String _name;						//customer's name
	private String _address;					//customer's address
	private int _distance;						//distance of customer from store
	private List<OrderReceipt> _receipts;		//order receipts for this customer
	private int _creditCard;					//credit card number
	private AtomicInteger _availableAmountInCreditCard;	//money remains in card

	/**
	 * Customer constructor
	 * @param id -customer's id
	 * @param name -customer's name
	 * @param address -customer's address
	 * @param distance -distance of customer from store
	 * @param creditCard -credit card number
	 * @param availableAmountInCreditCard -money remains in card
	 */
	public Customer(int id,String name,String address,int distance,int creditCard,int availableAmountInCreditCard) {
		_id=id;
		_name=name;
		_address=address;
		_distance=distance;
		_receipts= Collections.synchronizedList(new LinkedList<>());
		_creditCard=creditCard;
		_availableAmountInCreditCard=new AtomicInteger(availableAmountInCreditCard);
	}

	public String getName() {
		return _name;
	}

	public int getId() {
		return _id;
	}
	
	public String getAddress() {
		return _address;
	}

	public int getDistance() {
		return _distance;
	}

	public List<OrderReceipt> getCustomerReceiptList() {
		return _receipts;
	}

	public int getAvailableCreditAmount() {
		return _availableAmountInCreditCard.get();
	}

	public int getCreditNumber() {
		return _creditCard;
	}

	/**
	 * Update the custumer's money amount left in card after purchase
	 * using atomic integer method
	 * @param amountToCharge - the amount money to charge
	 */
	public void chargeCard(int amountToCharge){
		int localLeftAmount;
		do{
			localLeftAmount=_availableAmountInCreditCard.get();
		}
		while(!_availableAmountInCreditCard.compareAndSet(localLeftAmount,localLeftAmount-amountToCharge));
	}

	/**
	 * add the receipt r to the order receipts list of the customer
	 * @param r -the receipt to add
	 */
	public void addReceipt(OrderReceipt r){
		_receipts.add(r);
	}
}
