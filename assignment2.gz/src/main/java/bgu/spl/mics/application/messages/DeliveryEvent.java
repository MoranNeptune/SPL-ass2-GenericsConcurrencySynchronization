package bgu.spl.mics.application.messages;
import bgu.spl.mics.Event;
import bgu.spl.mics.application.passiveObjects.OrderReceipt;


/**
 * An event that is sent when the sells man of the store wishes to deliver the book that was bought
 */
public class DeliveryEvent implements Event {
    private OrderReceipt receipt; //holds the receipt thar represent the order of the customer
    private int distance; //holds the distance of the customer from the store
    private String address; //holds the address of the customer

    /**
     * DeliveryEvent constructor
     * @param receipt -holds the receipt thar represent the order of the customer
     * @param distance -holds the distance of the customer from the store
     * @param address -holds the address of the customer
     */
    public DeliveryEvent(OrderReceipt receipt, int distance, String address) {
        this.receipt = receipt;
        this.distance = distance;
        this.address = address;
    }

    public int getDistance() {
        return distance;
    }

    public OrderReceipt getOrderReceipt() {
        return receipt;
    }

    public String getAddress() {
        return address;
    }
}