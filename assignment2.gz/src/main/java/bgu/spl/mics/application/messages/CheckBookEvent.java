package bgu.spl.mics.application.messages;

import bgu.spl.mics.Event;

/**
 * An event that is sent when the sells man of the store wishes to
 * check if a book is in the inventory of the store
 */
public class CheckBookEvent implements Event {

    String bookName; //holds the name of the book
    int availableCreditAmount; //holds the available credit amount of the current customer

    /**
     * CheckBookEvent constructor
     * @param bookName -holds the name of the book
     * @param availableCreditAmount -holds the available credit amount of the current customer
     */
    public CheckBookEvent(String bookName,int availableCreditAmount){
        this.bookName=bookName;
        this.availableCreditAmount=availableCreditAmount;
    }

    public String getBookName() {
        return bookName;
    }

    public int getAvailableCreditAmount() {
        return availableCreditAmount;
    }
}
