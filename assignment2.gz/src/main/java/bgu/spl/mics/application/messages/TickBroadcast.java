package bgu.spl.mics.application.messages;

import bgu.spl.mics.Broadcast;

/**
 * A broadcast that is sent at every timeService tick
 */
public class TickBroadcast implements Broadcast {

    private int currTick; //holds the current tick in the timer

    /**
     * TickBroadcast constructor
     * @param currTick -holds the current tick in the timer
     */
    public TickBroadcast(int currTick){
        this.currTick=currTick;
    }

    public int getCurrTick(){
        return currTick;
    }
}
